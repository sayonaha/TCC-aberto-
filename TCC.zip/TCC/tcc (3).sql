-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31-Out-2023 às 22:36
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adm`
--

CREATE TABLE `adm` (
  `Login` varchar(10) NOT NULL,
  `senha` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `adm`
--

INSERT INTO `adm` (`Login`, `senha`) VALUES
('ADM', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `ID` int(11) NOT NULL,
  `Nome` text DEFAULT NULL,
  `Modalidade` varchar(50) DEFAULT NULL,
  `Descrever` longtext DEFAULT NULL,
  `Cupom` text DEFAULT NULL,
  `Contato` text DEFAULT NULL,
  `Link` text DEFAULT NULL,
  `Empresa` text DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`ID`, `Nome`, `Modalidade`, `Descrever`, `Cupom`, `Contato`, `Link`, `Empresa`, `imagem`) VALUES
(1, 'Como fumar', NULL, NULL, 'TIAGO', 'tiagofr02@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'Tiaguinho', NULL),
(2, 'Teste', 'teste', 'testando testando !', 'TESTE', 'teste@gmail.com', 'https://bard.google.com/chat/7c0eb19a65233946', 'testinho', NULL),
(3, 'aaa', NULL, NULL, 'AAA1', 'aaa@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'aaa', NULL),
(4, 'aaabb', NULL, NULL, 'AAA12', 'aaabb@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'aaabb', NULL),
(5, 'aaabbcc', NULL, NULL, 'AAA123', 'aaabbcc@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'aaabbcc', NULL),
(6, 'aaabbcc', NULL, NULL, 'AAA1234', 'aaabbccdd@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'aaabbccdd', NULL),
(7, 'aaabbccddee', NULL, NULL, 'AAA12345', 'aaabbccddee@gmail.com', 'https://www.facebook.com/tiago.oliveirafrol', 'aaabbccddee', NULL),
(8, 'aiai', 'ead', NULL, 'AIUIAIUI', '51987645532', 'https://www.facebook.com/tiago.oliveirafrol', 'uiui', NULL),
(9, 'poke', 'presencial', NULL, 'PokePoke', '51987452345', 'https://www.facebook.com/tiago.oliveirafrol', 'pokemon', NULL),
(10, 'pokemon', 'presencial', NULL, 'PokePoke12', '51987452345', 'https://www.facebook.com/tiago.oliveirafrol', 'pokemongo', NULL),
(11, 'pokemongo', 'presencial', NULL, 'PokePoke1212', '51987452345', 'https://www.facebook.com/tiago.oliveirafrol', 'pokemongogo', NULL),
(12, 'ai mds', 'ead', NULL, 'Deus', 'ceus@gmail.com', 'https://www.vatican.va/content/vatican/pt.html', 'Jesus', NULL),
(13, 'Rexona', 'EAD', '\r\n\r\nfreestar\r\n\r\nfreestar\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent dictum dolor ut enim rhoncus tincidunt. Curabitur a sapien sit amet quam scelerisque consectetur. Proin hendrerit tempor dignissim. Quisque tincidunt placerat magna eget tincidunt. Fusce et erat blandit, imperdiet lorem ut, vestibulum augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi id laoreet velit, id eleifend nunc. Nulla sed consequat metus.', 'LORE', '51987452345', 'https://www.vatican.va/content/vatican/pt.html', 'Tiaguinho', NULL),
(14, 'Sapo cururu', 'EAD', '\r\n\r\nfreestar\r\n\r\nfreestar\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent dictum dolor ut enim rhoncus tincidunt. Curabitur a sapien sit amet quam scelerisque consectetur. Proin hendrerit tempor dignissim. Quisque tincidunt placerat magna eget tincidunt. Fusce et erat blandit, imperdiet lorem ut, vestibulum augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi id laoreet velit, id eleifend nunc. Nulla sed consequat metus.', 'Cururu', 'ceus@gmail.com', 'https://www.vatican.va/content/vatican/pt.html', 'XUXA', NULL),
(15, 'Rico', 'EAD', '\r\n\r\n\r\nfreestar\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent dictum dolor ut enim rhoncus tincidunt. Curabitur a sapien sit amet quam scelerisque consectetur. Proin hendrerit tempor dignissim. Quisque tincidunt placerat magna eget tincidunt. Fusce et erat blandit, imperdiet lorem ut, vestibulum augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi id laoreet velit, id eleifend nunc. Nulla sed consequat metus.', 'Ricaa', 'rico@gmail.com', 'https://br.lipsum.com/feed/html', 'Primo Rico', NULL),
(16, 'Sapo cururu', 'presencial', '       var oldpath = files.Imagem.path; ', 'Ricaa', 'rico@gmail.com', 'https://br.lipsum.com/feed/html', 'rico', 'b5545083ea05d30d47b6f612745a5f39.jpeg'),
(17, 'node', 'EAD', 'SOCORRO DEUS', 'Tá quase', 'if@gmail.com', 'https://bard.google.com/chat/852dd396d57a0fc7', 'if', 'd187a18b5baba9ccd1fe3fe44d28f80d.jpeg'),
(18, 'ui', 'EAD', 'uiiiii', 'AAA123', 'hcl@outlook.com', 'https://www.hcltech.com/', 'XUXA', 'b8d651c375d7875c56dabb869f7f2b29.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `divulgações`
--

CREATE TABLE `divulgações` (
  `ID_divu` int(11) NOT NULL,
  `nome` text DEFAULT NULL,
  `Numerocel` int(11) DEFAULT NULL,
  `Redes` text DEFAULT NULL,
  `Telefone` int(11) DEFAULT NULL,
  `Faixapreço` text DEFAULT NULL,
  `Região` text DEFAULT NULL,
  `Descricao` text DEFAULT NULL,
  `Email` text DEFAULT NULL,
  `Toque` text DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `Senha` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `divulgações`
--

INSERT INTO `divulgações` (`ID_divu`, `nome`, `Numerocel`, `Redes`, `Telefone`, `Faixapreço`, `Região`, `Descricao`, `Email`, `Toque`, `imagem`, `user_id`, `Senha`) VALUES
(9, 'Alexandre de Odé ', 55, 'Inst: @Odé_Alex', 0, '150h-200h', 'Metropolitana de POA', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris leo mi, facilisis eu tristique sit amet, efficitur convallis eros. Donec sed orci mollis nibh suscipit tempor. Praesent molestie mi id odio imperdiet sollicitudin. Nunc auctor auctor arcu quis cursus. Nulla feugiat cursus metus, ac mattis velit pretium in. Suspendisse eu dolor ligula. Phasellus ullamcorper in ex id posuere. Integer sit amet quam egestas, tristique nisi eget, accumsan mauris. Nam dictum sem nulla, in imperdiet massa aliquam id. Proin congue dapibus quam eu auctor. In sed erat augue. Fusce ac posuere nunc.  Vestibulum tempor vestibulum rutrum. Vivamus venenatis placerat lacus quis cursus. Ut sed cursus mauris. Donec nec felis metus. Morbi ut nibh faucibus, bibendum mi in, consequat lacus. Integer volutpat blandit lore', 'alexandreTamb@gmail.com', 'umbanda, nação', '5c161485e23076be40f0ffa834f61c11.octet-stream', 18, 'odé');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Numero` varchar(15) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `cpf_cnpj` varchar(20) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `estado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`ID`, `Nome`, `Numero`, `email`, `senha`, `cpf_cnpj`, `cidade`, `estado`) VALUES
(17, 'Tiago ', '2147483647', 'tiago@gmail.com', '$2b$10$a57umQffrPHj9xKDGhnSaOdD2M3TE0KTi/kwXWKOhOyAy5JdDX/Nq', '2147483647', 'Gravataí', 'RS'),
(18, 'Alex', '(84) 99627-2029', 'alex@gmail.com', '$2b$10$cQL/BNsjHTlLnE3DZN4p/OH02MK3qpWjFP0MYsab8ZXgFi5aLuhEC', '13413784463', 'Natal', 'RN'),
(20, 'Maria', '5123654785', 'rex@gmail.com', '123', '0427837698', 'São Paulo', 'SP'),
(21, 'Douglas Kellermann', '5199623201', 'douglas@gmail.com', 'if', '023452102', 'Gravataí', 'RS');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`ID`);

--
-- Índices para tabela `divulgações`
--
ALTER TABLE `divulgações`
  ADD PRIMARY KEY (`ID_divu`),
  ADD KEY `ID_user_FK` (`user_id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `divulgações`
--
ALTER TABLE `divulgações`
  MODIFY `ID_divu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `divulgações`
--
ALTER TABLE `divulgações`
  ADD CONSTRAINT `ID_user_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
