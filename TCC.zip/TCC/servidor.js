const express = require('express');
const app = express();
var formidable = require("formidable");
var mysql = require('mysql');
var bcrypt = require("bcrypt");
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const saltRounds = 10;
var session = require('express-session');

app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: false,
    saveUninitialized: true
    }));

var con = mysql.createConnection({
host: "localhost",
user: "root",
password: "",
database: "tcc"
});
con.connect(function() {
console.log("Conectado!");
})


app.use(express.urlencoded({extended: true}))
app.set('view engine', 'ejs')
app.use( express.static("public") );
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/',function(req,res){
    res.render('tela_ini.ejs');
});



app.get('/divulgue', function(req, res){
    if (req.session.loggedin) {
         res.render('divulga.ejs');
        }else {
            res.render('tela_log_tamb.ejs', {mensagem: "Por favor realize o login para acessar a página"})
         } 
});

app.post('/divulgue', function (req, res) {
    var form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        // Certifique-se de que o ID do usuário esteja disponível na sessão
        var user_id = req.session.userID;

        if (!user_id) {
            return res.render('tela_log_tamb.ejs', { mensagem: "Faça login para acessar esta página" });
        }

        var oldpath = files.imagem.filepath;
        var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
        var nomeimg = hash + '.' + files.imagem.mimetype.split('/')[1];
        var newpath = path.join(__dirname, 'public/imagens/', nomeimg);
        fs.rename(oldpath, newpath, function (err) {
            if (err) throw err;
        });

        // Inserir dados na tabela 'divulgações' com o 'user_id'
        bcrypt.hash(req.body['senha'], saltRounds, function (err, hash) {
        var sql = "INSERT INTO divulgações (user_id, nome, Numerocel, Redes, Telefone, Faixapreço, Região, Descricao, Email, Toque, imagem, senha) VALUES ?";
        var values = [[user_id, fields['nome'], fields['Numerocel'], fields['Redes'], fields['Telefone'], fields['Faixapreço'], fields['Região'], fields['Descricao'], fields['Email'], fields['Toque'], nomeimg, fields['senha']]];
        con.query(sql, [values], function (err) {
            if (err) throw err;
            console.log("Dados de divulgação adicionados com sucesso");
        });
    });
    });
    res.redirect('/ver');
});



app.post('/inserir', function (req, res) {
    console.log('Dados do formulário recebidos:', req.body);

    // Primeiro, vamos verificar se o email ou CPF já existem na tabela
    var email = req.body['email'];
    var cpf = req.body['cpf_cnpj'];
    var checkExistingUserQuery = "SELECT email, cpf_cnpj FROM users WHERE email = ? OR cpf_cnpj = ?";
    con.query(checkExistingUserQuery, [email, cpf], function (err, results) {
        if (err) {
            console.error('Erro ao verificar a existência de dados:', err);
            throw err;
        }

        if (results.length > 0) {
            // Usuário(s) com email ou CPF já existente(s)
            var existingUserMessages = [];
            results.forEach(function (user) {
                if (user.email === email) {
                    res.render('tela_cadas_tamb.ejs' , { mensagem: "O email já está em uso" });
                }
                if (user.cpf_cnpj === cpf) {
                    res.render('tela_cadas_tamb.ejs' , { mensagem: "O CPF já está em uso" });
                }
            });

            // Retorne uma mensagem personalizada com os conflitos
         //   var errorMessage = "Não é possível cadastrar devido a conflitos nos seguintes campos:\n" + existingUserMessages.join("\n");
         //   console.log(errorMessage);
          //  res.send(errorMessage);
        } else {
            // Nenhum usuário com o email ou CPF foi encontrado, prossiga com a inserção.
            var sql = "INSERT INTO users (id, nome, numero, email, senha, cpf_cnpj, cidade, estado) VALUES ?";
            var values = [
                [req.body['ID'], req.body['Nome'], req.body['Numero'], req.body['email'], req.body['senha'], req.body['cpf_cnpj'], req.body['cidade'], req.body['estado']]
            ];
            con.query(sql, [values], function (err) {
                if (err) {
                    console.error('Erro ao inserir dados:', err);
                    throw err;
                }
                console.log('Usuário adicionado com sucesso.');
                res.redirect('/login');
            });
        }
    });
});




app.get('/cadastro', function (req, res){
    res.render('tela_cadas_tamb.ejs', { mensagem: "Bem-vindo à página de cadastro!" });
});

app.get('/adm', function (req, res){
    res.render('teste.ejs');
});


app.get('/loginadm', function (req, res){
    res.render('loginadm.ejs');
});

app.post('/loginadm', function(req, res){
    var senha = req.body['senha'];
    var login = req.body['Login']; 

    var sql = "SELECT * FROM adm where Login = ?";
    
    con.query(sql, [login], function (err, result){
        if (err) {
            console.log("Erro na consulta ao banco de dados:", err);
            throw err;
        }

        if (result.length === 0) {
            // Nenhum resultado encontrado para o login fornecido
            res.render('loginadm.ejs', { mensagem: "Login inválido" });
        } else {
            console.log("Senha da requisição:", senha);
            console.log("Senha do banco:", result[0]['senha']);

            if (senha === result[0]['senha']) {
                req.session.loggedin = true;
                req.session.userlogin = result[0]['Login'];
                res.redirect('/adm');
            } else {
                console.log("Senha inválida");
                res.render('loginadm.ejs', { mensagem: "Senha inválida" });
            }
        }
    });
});








app.get('/login', function(req, res) {
    res.render('tela_log_tamb.ejs', { mensagem: "Realize o Login" });
});

app.post('/login', function(req, res){
    const { email, senha } = req.body;

    // Realizar a autenticação do usuário
    const sql = "SELECT ID, senha FROM users WHERE email = ?";
    con.query(sql, [email], (err, result) => {
      if (err) {
        console.log("Erro na consulta ao banco de dados:", err);
        return res.render('tela_log_tamb.ejs', { mensagem: "Erro no login" });
      }
  
      if (result.length === 0) {
        return res.render('tela_log_tamb.ejs', { mensagem: "Credenciais inválidas" });
      }
  
      const user = result[0];
      
      // Verificar a senha com hash usando bcrypt
      bcrypt.compare(senha, user.senha, (err, resultado) => {
        if (err) {
          console.log("Erro na comparação de senhas:", err);
          return res.render('tela_log_tamb.ejs', { mensagem: "Erro no login" });
        }
  
        if (resultado) {
          req.session.loggedin = true;
          req.session.userID = user.ID; // Armazenar o ID do usuário na sessão
          res.redirect('/divulgue');
        } else {
          res.render('tela_log_tamb.ejs', { mensagem: "Credenciais inválidas" });
        }
      });
    });
  });
  //  var sql = "SELECT * FROM users where email= ?";
    //  con.query(sql, [email], function (err, result){
      //   if(err) throw err;
       //  if (result.length){
        //    bcrypt.compare(senha, result[0]['senha'], function(err, resultado){
              //   if (err) throw err;
               //  if (err) {
                 //  console.log("Erro na comparação de senhas:", err);
                  //   throw err;
             //  }
            
                //  if(resultado){
                     // req.session.loggedin = true;
                    //  req.session.username = result[0]['nome'];
                     // req.session.userID = result[0]['ID'];
                      //  res.redirect('/divulgue');
               //}
              //  else {res.render('tela_log_tamb.ejs',  {mensagem: "Senha inválida"})}
          //  });
       // }
       //else {res.render('tela_log_tamb.ejs',  {mensagem: "E-mail não encontrado"})}
   //});
    
//});

//app.get('/ver', function(req, res){
   // var sql = "SELECT * FROM divulgações"
    //con.query(sql, function(err, result, fields){
      //  if (err) throw err;
           //  res.render('veja2.ejs', {dadosDivulgações: result})
   // });
    
//});

app.get('/ver', (req, res) => {
    const perPage = 10; // Número de itens por página
    const page = req.query.page || 1; // Página atual
    const startIndex = (page - 1) * perPage;
    let sql = "SELECT * FROM divulgações";
    const values = [];

    // Receba os parâmetros da consulta para filtragem
    const { Região, Faixapreço, Toque } = req.query;

    console.log('Valor de Região:', Região);
    console.log('Valor de Faixapreço:', Faixapreço);
    console.log('Valor de Toque:', Toque);

    // Construa cláusulas WHERE com base nas opções fornecidas
    const whereClauses = [];
    if (Toque) {
        whereClauses.push("Toque LIKE ?");
        values.push(`%${Toque}%`);
    }
    if (Faixapreço) {
        // Ajuste para lidar com faixas de preço no formato "100h - 200h" ou "200h - 300h"
        const faixaPrecoParts = Faixapreço.split('-');
        if (faixaPrecoParts.length === 2) {
            whereClauses.push("(Faixapreço >= ? AND Faixapreço <= ?)");
            values.push(faixaPrecoParts[0].trim(), faixaPrecoParts[1].trim());
        }
    }
    if (Região) {
        // Modificação para permitir pesquisa de partes do texto na Região
        whereClauses.push("Região LIKE ?");
        values.push(`%${Região}%`);
    }

    console.log('Consulta SQL gerada:', sql); // Adicione este console para rastrear a consulta SQL gerada
    console.log('Valores da consulta SQL:', values); // Adicione este console para rastrear os valores usados na consulta

    if (whereClauses.length > 0) {
        sql += " WHERE " + whereClauses.join(' AND ');
    }

    // Adicione LIMIT à consulta SQL
    sql += " LIMIT ?, ?";
    values.push(startIndex, perPage);

    con.query(sql, values, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ error: 'Erro ao buscar divulgações.' });
        } else {
            // Consulta bem-sucedida, renderize a página com os dados
            res.render('veja2.ejs', { dadosDivulgações: result });
        }
    });
});

app.get('/ver/todas', (req, res) => {
    // Essa rota mostrará todas as divulgações sem filtros

    let sql = "SELECT * FROM divulgações";
    
    con.query(sql, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ error: 'Erro ao buscar todas as divulgações.' });
        } else {
            // Consulta bem-sucedida, renderize a página com todos os dados
            res.render('veja2.ejs', { dadosDivulgações: result });
        }
    });
});






//app.get('/apagar/:id', function(req, res){
    //var id = req.params.id;
  //  var sql = "DELETE FROM divulgações WHERE id =  ?";
  //  con.query(sql, id, function(err, result){
      //  if (err) throw err;
       // console.log({dadosDivulgações: result})
  //  });
   // res.redirect("/ver");
//});





app.get('/logout', function (req, res) {
    req.session.destroy(function () {
        // cannot access session here
    })
    res.redirect('/');
});

app.get('/pesquisar', function (req, res){
    res.render('teste.ejs', );
});



app.post('/pesquisar', function (req, res){
    console.log("Rota pesquisar alcançada"); 
    console.log("Dados recebidos", req.body);
    var sql = "SELECT * FROM users where Nome LIKE ?"
    var nome = '%' + req.body.Nome + '%'; // Adiciona os caracteres curinga
    console.log("Valor do nome:", nome);
    con.query(sql, nome, function (err, result) { // Usa 'nome' em vez de 'id'
        if (err) throw err;
        console.log("Resultado da consulta", result);
        res.render('excluir.ejs', { dadosResu: result });
    });
});

app.post("/excluir", (req, res) => {
    var userID = req.body.id;
    if (!userID) {
        res.status(400).send('ID do usuário não fornecido corretamente');
        return;
    }

    // Verifique se há registros relacionados na tabela divulgações
    con.query('SELECT * FROM divulgações WHERE user_id = ?', [userID], function (error, results) {
        if (error) {
            console.error("Erro na consulta SQL: " + error.message);
            throw error;
        }

        // Se houver registros relacionados, exclua-os
        if (results.length > 0) {
            con.query('DELETE FROM divulgações WHERE user_id = ?', [userID], function (error) {
                if (error) {
                    console.error("Erro ao excluir registros na tabela divulgações: " + error.message);
                    throw error;
                }
            });
        }

        // Em seguida, exclua o usuário da tabela users
        con.query('DELETE FROM users WHERE ID = ?', [userID], function (error) {
            console.log("Consulta SQL: DELETE FROM users WHERE ID = " + userID);
            if (error) {
                console.error("Erro na consulta SQL: " + error.message);
                throw error;
            }
            console.log("Usuário excluído com sucesso.");
            res.send('Usuário excluído com sucesso.');
        });
    });
});


app.get('/Addcursos', function (req, res){
    res.render('addcursos.ejs');
});

app.post('/Addcursos', function(req, res){
    var form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {

        var oldpath = files.imagem.filepath;
        var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
        var nomeimg = hash + '.' + files.imagem.mimetype.split('/')[1];
        var newpath = path.join(__dirname, 'public/imagens/', nomeimg);
        fs.rename(oldpath, newpath, function (err) {
            if (err) throw err;
        });
      //  console.log("Descrever: " + fields['Descrever']);
        var sql = "INSERT INTO cursos (Nome, Modalidade, Empresa, Descrever, Cupom, Contato, Link, imagem) VALUES  (?, ?, ?, ?, ?, ?, ?, ?)";
        var values = [fields['Nome'], fields['Modalidade'], fields['Empresa'], fields['Descrever'], fields['Cupom'], fields['Contato'], fields['Link'], nomeimg];
        
        con.query(sql, values, function (err) {
            if (err) {
                console.error(err); 
                throw err;
            }
            console.log("Adicionado");
        });
    });
    res.redirect('/cursos');
});

app.get('/cursos', function(req, res){
    var sql ="SELECT * FROM cursos"
    con.query(sql, function (err, result) {
    if (err) throw err;
    res.render('cursos.ejs', {cursos: result})
    });
});

app.get('/pesquisarUser', function (req, res){
    res.render('pesqui.ejs');
});



app.post('/pesquisarUser', function (req, res){
    console.log("Rota pesquisar user alcançada"); 
    console.log("Dados recebidos", req.body);
    var sql = "SELECT * FROM users where cpf_cnpj LIKE ?"
    var num = '%' + req.body.cpf_cnpj + '%';
    console.log("Valor do cpf:", num);
    con.query(sql, num, function (err, result) {
        if (err) throw err;
        console.log("Resultado da consulta", result);
        res.render('mostraUser.ejs', { dadosUsers: result });
    });
});

app.get('/editarUser/:cpf', function (req, res) {
    var cpf = req.params.cpf;
    console.log('CPF recebido na rota:', cpf);
    var sql = "SELECT * FROM users WHERE cpf_cnpj = ?";
    con.query(sql, [cpf], function (err, result) {
        if (err) throw err;
        console.log('Resultado da consulta no banco de dados:', result);
        if (result.length === 0) {
            console.log('Usuário não encontrado');
            res.render('mostraUser.ejs', { mensagem: "Não foi possível editar" });
        }
        res.render('edição.ejs', { dadosUsers: result });
    });
});


app.post('/editarUser/:cpf_cnpj', function (req, res) {
    var cpf = req.params.cpf_cnpj;
    var updatedData = req.body; // Os dados atualizados do formulário, incluindo o novo CPF

    // Verifique a unicidade do novo CPF se desejar
    var newCPF = updatedData.cpf_cnpj;
    var sqlCheckUniqueness = "SELECT * FROM users WHERE cpf_cnpj = ? AND cpf_cnpj != ?";
    con.query(sqlCheckUniqueness, [newCPF, cpf], function (err, result) {
        if (err) throw err;

        if (result.length > 0) {
            console.log('CPF já está em uso por outro usuário');
            // Trate aqui a situação de CPF duplicado, como mostrar uma mensagem de erro ou redirecionar de volta ao formulário de edição
        } else {
            // Execute uma consulta SQL para atualizar os dados do usuário com base no CPF
            var sql = "UPDATE users SET ? WHERE cpf_cnpj = ?";
            con.query(sql, [updatedData, cpf], function (err) {
                if (err) throw err;
                console.log('Dados do usuário atualizados com sucesso');
                res.redirect('/mostraUser'); // Redireciona para a página inicial ou outra página apropriada
            });
        }
    });
});

app.get('/pesquisarDivu', function (req, res){
    res.render('pesquisar.ejs');
});



app.post('/pesquisarDivu', function (req, res){
    var senha = req.body['senha'];

    // Realizar a pesquisa de divulgação por senha
    var sql = "SELECT * FROM divulgações WHERE senha = ?";
    con.query(sql, [senha], function (err, result) {
        if (err) {
            console.log("Erro na consulta ao banco de dados:", err);
            throw err;
        }

        if (result.length === 0) {
            res.send('Nenhuma divulgação encontrada com a senha fornecida.');
        } else {
            res.render('resultados.ejs', { dadosDivulgacao: result });
        }
    });
});

app.get('/editarDivulgacao/:id', function (req, res) {
    var id = req.params.id;
    // Consulta o banco de dados para recuperar os dados da divulgação com o ID especificado
    var sql = "SELECT * FROM divulgações WHERE ID_divu = ?";
    con.query(sql, [id], function (err, result) {
        if (err) throw err;
        res.render('editarDivulgacao.ejs', { dadosDivulgacao: result });
    });
});

app.post('/editarDivulgacao/:id', function (req, res) {
    var id = req.params.id; // ID da divulgação a ser editada
    var updatedData = req.body; // Dados atualizados do formulário
    var imagem = req.files.imagem; // Arquivo de imagem enviado

    // Se uma nova imagem foi enviada, faça o upload dela
    if (imagem) {
        var oldpath = imagem.path;
        var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
        var nomeimg = hash + '.' + imagem.name.split('.').pop(); // Manter a extensão original
        var newpath = path.join(__dirname, 'public/imagens/', nomeimg);
        
        // Mova a imagem para a pasta de imagens
        fs.rename(oldpath, newpath, function (err) {
            if (err) throw err;
        });

        // Atualize o nome da imagem no objeto de dados atualizados
        updatedData.imagem = nomeimg;
    }

    // Execute uma consulta SQL para atualizar os dados da divulgação com base no ID
    var sql = "UPDATE divulgações SET ? WHERE ID_Divu = ?";
    con.query(sql, [updatedData, id], function (err) {
        if (err) {
            console.error('Erro ao atualizar os dados da divulgação:', err);
            throw err;
        }
        console.log('Dados da divulgação atualizados com sucesso.');
        res.redirect('/ver'); // Redirecione para a página de visualização após a edição
    });
});



app.listen(3000,function(){
    console.log("Servidor Escutando na porta 3000");
});